const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.TiledBg,
		C3.Plugins.Sprite,
		C3.Plugins.Mouse,
		C3.Plugins.Mouse.Cnds.IsOverObject,
		C3.Plugins.Sprite.Acts.SetAnim,
		C3.Plugins.Mouse.Cnds.OnClick,
		C3.Plugins.System.Acts.GoToLayout,
		C3.Plugins.System.Acts.NextPrevLayout
	];
};
self.C3_JsPropNameTable = [
	{ТайловыйФон: 0},
	{get_play: 0},
	{get_exit: 0},
	{Мышь: 0},
	{Спрайт: 0},
	{Спрайт2: 0}
];

self.InstanceType = {
	ТайловыйФон: class extends self.ITiledBackgroundInstance {},
	get_play: class extends self.ISpriteInstance {},
	get_exit: class extends self.ISpriteInstance {},
	Мышь: class extends self.IInstance {},
	Спрайт: class extends self.ISpriteInstance {},
	Спрайт2: class extends self.ISpriteInstance {}
}